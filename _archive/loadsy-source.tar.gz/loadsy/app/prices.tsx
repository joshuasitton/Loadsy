import { useRouter } from 'expo-router';
import * as WebBrowser from 'expo-web-browser';
import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { fetchQuotes } from '../src/api/rentals';
import {
  formatUSD,
  QUOTE_FILTER_LABEL,
  sortQuotes,
  VENDOR_LABEL,
  VENDOR_SEARCH_URL,
  type QuoteFilter,
} from '../src/domain/quotes';
import type { RentalQuote } from '../src/domain/types';
import { TRUCK_LABEL } from '../src/domain/truck';
import { useMove } from '../src/state/moveStore';
import {
  Banner,
  Card,
  Chip,
  EstimateTag,
  PrimaryButton,
  Screen,
  SecondaryButton,
  SectionLabel,
} from '../src/ui/components';
import { colors, radius, space, type } from '../src/ui/theme';

/** Screen 4 — Local Prices. */

const FILTERS: QuoteFilter[] = ['bestMatch', 'cheapest', 'earliest'];

export default function PricesScreen() {
  const router = useRouter();
  const { move, dispatch, recommendation } = useMove();
  const [zipDraft, setZipDraft] = useState(move.originZip);
  const [quotes, setQuotes] = useState<RentalQuote[] | null>(null);
  const [filter, setFilter] = useState<QuoteFilter>('bestMatch');
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);

  const zip = move.originZip;
  const isoDate = move.moveDate ?? new Date().toISOString();

  const load = useCallback(async () => {
    if (zip.length < 5) return;
    setLoading(true);
    setFailed(false);
    try {
      setQuotes(await fetchQuotes(recommendation.size, zip, isoDate));
    } catch {
      setFailed(true);
      setQuotes([]);
    } finally {
      setLoading(false);
    }
  }, [zip, isoDate, recommendation.size]);

  useEffect(() => {
    void load();
  }, [load]);

  // Client-side re-sort only — spec §3 Screen 4 forbids an API call per filter.
  const sorted = useMemo(() => (quotes ? sortQuotes(quotes, filter) : []), [quotes, filter]);

  async function openUrl(url: string) {
    // In-app browser (SFSafariViewController on iOS) so the user never fully leaves.
    await WebBrowser.openBrowserAsync(url, {
      presentationStyle: WebBrowser.WebBrowserPresentationStyle.PAGE_SHEET,
      toolbarColor: colors.bg,
      controlsColor: colors.accent,
    });
  }

  if (zip.length < 5) {
    return (
      <Screen>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Card style={styles.zipCard}>
            <SectionLabel>WHERE ARE YOU MOVING FROM?</SectionLabel>
            <Text style={styles.zipBody}>
              Rental rates and availability are local. Your ZIP stays on your device — we only use
              it to look up nearby depots.
            </Text>
            <TextInput
              value={zipDraft}
              onChangeText={(v) => setZipDraft(v.replace(/\D/g, '').slice(0, 5))}
              keyboardType="number-pad"
              placeholder="20147"
              placeholderTextColor={colors.textDim}
              style={styles.zipInput}
              accessibilityLabel="Origin ZIP code"
              maxLength={5}
            />
            <PrimaryButton
              title="Find local prices"
              disabled={zipDraft.length < 5}
              onPress={() => dispatch({ type: 'setOriginZip', zip: zipDraft })}
            />
          </Card>
        </ScrollView>
      </Screen>
    );
  }

  return (
    <Screen>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>{TRUCK_LABEL[recommendation.size]} near {zip}</Text>
          <Text style={styles.headerSubtitle}>
            Every price below is an estimate. The vendor confirms the exact total at booking.
          </Text>
        </View>

        <View style={styles.filterRow}>
          {FILTERS.map((f) => (
            <Chip
              key={f}
              label={QUOTE_FILTER_LABEL[f]}
              active={filter === f}
              onPress={() => setFilter(f)}
              accessibilityLabel={`Sort by ${QUOTE_FILTER_LABEL[f]}`}
            />
          ))}
        </View>

        {loading ? (
          <View style={styles.busy}>
            <ActivityIndicator color={colors.accent} />
            <Text style={styles.busyText}>Checking local rates…</Text>
          </View>
        ) : sorted.length === 0 ? (
          <EmptyState zip={zip} failed={failed} onRetry={load} onOpen={openUrl} />
        ) : (
          sorted.map((quote) => (
            <QuoteCard
              key={quote.id}
              quote={quote}
              onOpenBreakdown={() => router.push({ pathname: '/quote/[id]', params: { id: quote.id } })}
              onViewDeal={() => openUrl(quote.deepLinkURL)}
            />
          ))
        )}

        {sorted.length > 0 ? (
          <Text style={styles.disclosure}>
            Loadsy shows estimated totals so you can compare like for like. We do not add fees, and
            we may earn a commission when you book through a link here.
          </Text>
        ) : null}
      </ScrollView>

      <View style={styles.footer}>
        <PrimaryButton
          title="Build my packing plan"
          onPress={() => {
            dispatch({ type: 'setStatus', status: 'packingPlan' });
            router.push('/packing');
          }}
        />
      </View>
    </Screen>
  );
}

function QuoteCard({
  quote,
  onOpenBreakdown,
  onViewDeal,
}: {
  quote: RentalQuote;
  onOpenBreakdown: () => void;
  onViewDeal: () => void;
}) {
  const available = new Date(quote.earliestAvailability);
  return (
    <Card
      onPress={onOpenBreakdown}
      accessibilityLabel={`${VENDOR_LABEL[quote.vendor]}, estimated total ${formatUSD(quote.estimatedTotal)}. Tap for the full price breakdown.`}
      style={styles.quoteCard}
    >
      <View style={styles.quoteTop}>
        <View style={styles.quoteVendorBlock}>
          <Text style={styles.quoteVendor}>{VENDOR_LABEL[quote.vendor]}</Text>
          <Text style={styles.quoteMeta}>
            Available {available.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} ·{' '}
            {Math.round(quote.distanceMiles)} mi
          </Text>
        </View>
        <View style={styles.quotePriceBlock}>
          <Text style={styles.quotePrice}>{formatUSD(quote.estimatedTotal)}</Text>
          <EstimateTag compact />
        </View>
      </View>

      <Text style={styles.quoteBreakdownHint}>
        {formatUSD(quote.baseRate)} base + mileage, fuel and coverage · tap for the full breakdown
      </Text>

      <SecondaryButton
        title="View Deal"
        onPress={onViewDeal}
        accessibilityLabel={`View this deal on ${VENDOR_LABEL[quote.vendor]}, opens in an in-app browser`}
      />
    </Card>
  );
}

function EmptyState({
  zip,
  failed,
  onRetry,
  onOpen,
}: {
  zip: string;
  failed: boolean;
  onRetry: () => void;
  onOpen: (url: string) => void;
}) {
  const vendors = Object.entries(VENDOR_SEARCH_URL).filter(([vendor]) => vendor !== 'local');

  return (
    <View style={styles.emptyWrap}>
      <Banner
        tone={failed ? 'danger' : 'amber'}
        title={failed ? "Couldn't reach the rate lookup" : `No rates came back for ${zip}`}
        message="You can still search each vendor directly — here are the links, so this isn't a dead end."
      />
      <View style={styles.emptyLinks}>
        {vendors.map(([vendor, url]) => (
          <Pressable
            key={vendor}
            accessibilityRole="link"
            accessibilityLabel={`Search on ${VENDOR_LABEL[vendor as keyof typeof VENDOR_LABEL]}`}
            onPress={() => onOpen(url)}
            style={styles.emptyLink}
          >
            <Text style={styles.emptyLinkText}>
              Search on {VENDOR_LABEL[vendor as keyof typeof VENDOR_LABEL]} →
            </Text>
          </Pressable>
        ))}
      </View>
      <SecondaryButton title="Try again" onPress={onRetry} />
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: 120, gap: space.lg },
  header: { gap: space.xs, marginTop: space.sm },
  headerTitle: { ...type.title, color: colors.text },
  headerSubtitle: { ...type.caption, color: colors.textMuted, lineHeight: 19 },
  filterRow: { flexDirection: 'row', gap: space.sm },
  busy: { alignItems: 'center', gap: space.md, paddingVertical: space.xxl },
  busyText: { ...type.body, color: colors.textMuted },
  quoteCard: { gap: space.md },
  quoteTop: { flexDirection: 'row', justifyContent: 'space-between', gap: space.md },
  quoteVendorBlock: { flex: 1, gap: 2 },
  quoteVendor: { ...type.heading, color: colors.text },
  quoteMeta: { ...type.caption, color: colors.textMuted },
  quotePriceBlock: { alignItems: 'flex-end', gap: space.xs },
  quotePrice: { ...type.title, color: colors.text },
  quoteBreakdownHint: { ...type.caption, color: colors.textDim, lineHeight: 18 },
  disclosure: { ...type.caption, color: colors.textDim, lineHeight: 18 },
  emptyWrap: { gap: space.lg },
  emptyLinks: { gap: space.sm },
  emptyLink: {
    paddingVertical: space.md,
    paddingHorizontal: space.lg,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    minHeight: 48,
    justifyContent: 'center',
  },
  emptyLinkText: { ...type.body, color: colors.accent },
  zipCard: { gap: space.md, marginTop: space.lg },
  zipBody: { ...type.caption, color: colors.textMuted, lineHeight: 19 },
  zipInput: {
    backgroundColor: colors.surfaceRaised,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: space.lg,
    color: colors.text,
    ...type.title,
    letterSpacing: 4,
    textAlign: 'center',
    minHeight: 60,
  },
  footer: {
    padding: space.lg,
    paddingBottom: space.xl,
    backgroundColor: colors.bg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
