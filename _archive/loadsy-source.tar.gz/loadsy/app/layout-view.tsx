import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { useMemo, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SvgXml } from 'react-native-svg';
import { TRUCK_LABEL } from '../src/domain/truck';
import { allItems } from '../src/domain/volume';
import { computeZones, renderTruckMapSVG, type TruckView } from '../src/truckmap/renderSvg';
import { useMove } from '../src/state/moveStore';
import { Banner, Card, Chip, PrimaryButton, Screen, SecondaryButton } from '../src/ui/components';
import { colors, radius, space, type } from '../src/ui/theme';

/** Screen 6 — Truck Layout. 3D / Top view toggle, Save Plan and Share. */

export default function LayoutViewScreen() {
  const { move, packingPlan, recommendation } = useMove();
  const [view, setView] = useState<TruckView>('top');
  const [saved, setSaved] = useState(false);

  const items = allItems(move);
  const svg = useMemo(
    () => renderTruckMapSVG(items, recommendation.size, view),
    [items, recommendation.size, view],
  );
  const zones = useMemo(() => computeZones(items), [items]);

  async function share() {
    try {
      const path = `${FileSystem.cacheDirectory}loadsy-truck-plan.svg`;
      await FileSystem.writeAsStringAsync(path, svg);
      if (!(await Sharing.isAvailableAsync())) {
        Alert.alert('Sharing unavailable', 'This device cannot share files right now.');
        return;
      }
      await Sharing.shareAsync(path, { mimeType: 'image/svg+xml', dialogTitle: 'Loadsy truck plan' });
    } catch {
      Alert.alert("Couldn't share the plan", 'Try saving it to this device instead.');
    }
  }

  if (items.length === 0) {
    return (
      <Screen>
        <View style={styles.emptyWrap}>
          <Banner
            tone="neutral"
            title="Nothing to lay out yet"
            message="Add your inventory and the truck diagram builds itself."
          />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <Text style={styles.title}>{TRUCK_LABEL[recommendation.size]}</Text>
          <Text style={styles.subtitle}>
            {recommendation.adjustedCuFt} ft³ across {zones.length}{' '}
            {zones.length === 1 ? 'load zone' : 'load zones'}
          </Text>
        </View>

        <View style={styles.tabs}>
          <Chip
            label="Top View"
            active={view === 'top'}
            onPress={() => setView('top')}
            accessibilityLabel="Show the top-down view"
          />
          <Chip
            label="3D View"
            active={view === '3d'}
            onPress={() => setView('3d')}
            accessibilityLabel="Show the three-dimensional view"
          />
        </View>

        <Card style={styles.diagramCard}>
          <View style={styles.diagram}>
            <SvgXml xml={svg} width="100%" height="100%" />
          </View>
        </Card>

        <Card style={styles.legend}>
          {zones.map((zone) => (
            <View key={zone.step} style={styles.legendRow}>
              <View style={[styles.legendDot, { backgroundColor: zone.color }]} />
              <Text style={styles.legendLabel}>
                {zone.step}. {zone.label}
              </Text>
              <Text style={styles.legendValue}>
                {zone.cubicFeet} ft³ · {Math.round(zone.fraction * 100)}%
              </Text>
            </View>
          ))}
        </Card>

        <Text style={styles.caveat}>
          This is a load-zone diagram, not a piece-by-piece packing solution. It shows where each
          group belongs and how much of the truck it takes up.
        </Text>

        <View style={styles.actions}>
          <PrimaryButton
            title={saved ? 'Plan saved' : 'Save plan to this device'}
            onPress={() => setSaved(true)}
            disabled={saved || !packingPlan}
          />
          <SecondaryButton title="Share" onPress={share} accessibilityLabel="Share the truck plan" />
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: space.xxl, gap: space.lg },
  emptyWrap: { padding: space.lg, marginTop: space.xl },
  header: { gap: 2, marginTop: space.sm },
  title: { ...type.title, color: colors.text },
  subtitle: { ...type.caption, color: colors.textMuted },
  tabs: { flexDirection: 'row', gap: space.sm },
  diagramCard: { padding: space.sm, backgroundColor: colors.surfaceRaised },
  diagram: { height: 210, borderRadius: radius.sm, overflow: 'hidden' },
  legend: { gap: space.md },
  legendRow: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendLabel: { ...type.body, color: colors.text, flex: 1 },
  legendValue: { ...type.caption, color: colors.textMuted },
  caveat: { ...type.caption, color: colors.textDim, lineHeight: 18 },
  actions: { gap: space.md },
});
