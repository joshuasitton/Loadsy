import { useRouter } from 'expo-router';
import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import { fetchPackingPlan } from '../src/api/packingPlan';
import { stepForItem } from '../src/domain/packing';
import type { InventoryItem, LoadStep } from '../src/domain/types';
import { allItems, roomCubicFeet } from '../src/domain/volume';
import { useMove } from '../src/state/moveStore';
import { Banner, Card, Chip, PrimaryButton, Screen, SectionLabel } from '../src/ui/components';
import { colors, space, type } from '../src/ui/theme';

/** Screen 5 — Packing Plan. Two tabs: Load Plan and By Room. */

type Tab = 'load' | 'room';

export default function PackingScreen() {
  const router = useRouter();
  const { move, packingPlan, dispatch, recommendation } = useMove();
  const [tab, setTab] = useState<Tab>('load');
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);

  const items = allItems(move);

  const build = useCallback(async () => {
    if (items.length === 0) return;
    setLoading(true);
    setFailed(false);
    try {
      const plan = await fetchPackingPlan(move.id, items, recommendation.size);
      dispatch({ type: 'setPackingPlan', plan });
    } catch {
      setFailed(true);
    } finally {
      setLoading(false);
    }
    // `items` is derived fresh each render; the item count and move id are what
    // actually decide whether a rebuild is needed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [move.id, items.length, recommendation.size, dispatch]);

  useEffect(() => {
    if (!packingPlan && items.length > 0) void build();
  }, [packingPlan, items.length, build]);

  if (items.length === 0) {
    return (
      <Screen>
        <View style={styles.emptyWrap}>
          <Banner
            tone="neutral"
            title="No inventory yet"
            message="Your load order comes from what you are actually moving. Add a room and we'll build it."
          />
          <PrimaryButton title="Capture a room" onPress={() => router.push('/capture')} />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.tabs}>
          <Chip label="Load Plan" active={tab === 'load'} onPress={() => setTab('load')} />
          <Chip label="By Room" active={tab === 'room'} onPress={() => setTab('room')} />
        </View>

        {failed ? (
          <Banner
            tone="danger"
            title="Couldn't build the plan"
            message="Something went wrong on our side. Tap below to try again."
          />
        ) : null}

        {loading ? (
          <View style={styles.busy}>
            <ActivityIndicator color={colors.accent} />
            <Text style={styles.busyText}>Working out the load order…</Text>
          </View>
        ) : tab === 'load' ? (
          <LoadPlanTab steps={packingPlan?.loadSteps ?? []} items={items} onRetry={build} failed={failed} />
        ) : (
          <ByRoomTab move={move} />
        )}
      </ScrollView>

      <View style={styles.footer}>
        <PrimaryButton
          title="See the truck layout"
          onPress={() => router.push('/layout-view')}
          disabled={!packingPlan}
        />
      </View>
    </Screen>
  );
}

function LoadPlanTab({
  steps,
  items,
  onRetry,
  failed,
}: {
  steps: LoadStep[];
  items: InventoryItem[];
  onRetry: () => void;
  failed: boolean;
}) {
  const byId = new Map(items.map((item) => [item.id, item]));

  if (steps.length === 0) {
    return (
      <View style={styles.emptyWrap}>
        <PrimaryButton title={failed ? 'Try again' : 'Build my plan'} onPress={onRetry} />
      </View>
    );
  }

  return (
    <View style={styles.steps}>
      <Text style={styles.intro}>
        Load back to front. Each step goes in before the one below it — that order is what keeps the
        weight over the axle and the fragile things reachable.
      </Text>

      {steps.map((step) => (
        <Card key={step.id} style={styles.step}>
          <View style={styles.stepHeader}>
            <View style={styles.stepNumber}>
              <Text style={styles.stepNumberText}>{step.order}</Text>
            </View>
            <Text style={styles.stepTitle}>{step.title}</Text>
          </View>
          <Text style={styles.stepInstruction}>{step.instruction}</Text>
          <View style={styles.stepItems}>
            {step.itemIds.map((itemId) => {
              const item = byId.get(itemId);
              if (!item) return null;
              return (
                <View key={itemId} style={styles.stepItem}>
                  <Text style={styles.stepItemName}>{item.name}</Text>
                  <Text style={styles.stepItemMeta}>
                    {item.estimatedWeightClass}
                    {item.isFragile ? ' · fragile' : ''} · {item.cubicFeet} ft³
                  </Text>
                </View>
              );
            })}
          </View>
        </Card>
      ))}
    </View>
  );
}

function ByRoomTab({ move }: { move: ReturnType<typeof useMove>['move'] }) {
  return (
    <View style={styles.rooms}>
      <Text style={styles.intro}>
        The same items, grouped by where they are now — useful while you are boxing up rather than
        loading.
      </Text>

      {move.rooms.map((room) => (
        <Card key={room.id} style={styles.room}>
          <View style={styles.roomHeader}>
            <Text style={styles.roomName}>{room.name}</Text>
            <Text style={styles.roomTotal}>{roomCubicFeet(room)} ft³</Text>
          </View>
          <SectionLabel>{room.items.length} ITEMS</SectionLabel>
          {room.items.map((item) => (
            <View key={item.id} style={styles.roomItem}>
              <Text style={styles.roomItemName}>{item.name}</Text>
              <Text style={styles.roomItemStep}>Load step {stepForItem(item)}</Text>
            </View>
          ))}
        </Card>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: space.lg, paddingBottom: 120, gap: space.lg },
  tabs: { flexDirection: 'row', gap: space.sm, marginTop: space.sm },
  intro: { ...type.caption, color: colors.textMuted, lineHeight: 19 },
  busy: { alignItems: 'center', gap: space.md, paddingVertical: space.xxl },
  busyText: { ...type.body, color: colors.textMuted },
  emptyWrap: { padding: space.lg, gap: space.lg, marginTop: space.xl },
  steps: { gap: space.md },
  step: { gap: space.md },
  stepHeader: { flexDirection: 'row', alignItems: 'center', gap: space.md },
  stepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNumberText: { ...type.caption, fontWeight: '700', color: colors.accentText },
  stepTitle: { ...type.heading, color: colors.text },
  stepInstruction: { ...type.caption, color: colors.textMuted, lineHeight: 20 },
  stepItems: { gap: space.sm, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: space.md },
  stepItem: { flexDirection: 'row', justifyContent: 'space-between', gap: space.md },
  stepItemName: { ...type.caption, color: colors.text, flex: 1 },
  stepItemMeta: { ...type.caption, color: colors.textDim, fontSize: 12 },
  rooms: { gap: space.md },
  room: { gap: space.sm },
  roomHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline' },
  roomName: { ...type.heading, color: colors.text },
  roomTotal: { ...type.caption, color: colors.textMuted },
  roomItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: space.md,
    paddingVertical: space.xs,
  },
  roomItemName: { ...type.caption, color: colors.text, flex: 1 },
  roomItemStep: { ...type.caption, color: colors.textDim, fontSize: 12 },
  footer: {
    padding: space.lg,
    paddingBottom: space.xl,
    backgroundColor: colors.bg,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
});
