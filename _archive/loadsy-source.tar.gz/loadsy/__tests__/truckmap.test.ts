import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeZones, renderTruckMapSVG } from '../src/truckmap/renderSvg';
import { makeItem, resetIds } from './helpers';

test('zone fractions always sum to 1', () => {
  resetIds();
  const zones = computeZones([
    makeItem({ id: 'a', category: 'furniture', estimatedWeightClass: 'heavy', cubicFeet: 60 }),
    makeItem({ id: 'b', category: 'box', estimatedWeightClass: 'light', cubicFeet: 20 }),
    makeItem({ id: 'c', category: 'fragile', isFragile: true, cubicFeet: 20 }),
  ]);
  const sum = zones.reduce((acc, z) => acc + z.fraction, 0);
  assert.ok(Math.abs(sum - 1) < 1e-9, `fractions summed to ${sum}`);
});

test('zones come back in load order with no empty zones', () => {
  resetIds();
  const zones = computeZones([
    makeItem({ id: 'a', category: 'box', estimatedWeightClass: 'light', cubicFeet: 10 }),
    makeItem({ id: 'b', category: 'appliance', estimatedWeightClass: 'heavy', cubicFeet: 40 }),
  ]);
  assert.deepEqual(zones.map((z) => z.step), [1, 5]);
  for (const zone of zones) assert.ok(zone.cubicFeet > 0);
});

test('an empty inventory renders without dividing by zero', () => {
  assert.deepEqual(computeZones([]), []);
  const svg = renderTruckMapSVG([], '15ft', 'top');
  assert.ok(svg.startsWith('<svg'));
  assert.ok(svg.endsWith('</svg>'));
});

test('the SVG is deterministic for the same items (Save Plan round-trip)', () => {
  resetIds();
  const items = [
    makeItem({ id: 'a', category: 'furniture', estimatedWeightClass: 'heavy', cubicFeet: 60 }),
    makeItem({ id: 'b', category: 'box', estimatedWeightClass: 'heavy', cubicFeet: 25 }),
  ];
  assert.equal(renderTruckMapSVG(items, '20ft', 'top'), renderTruckMapSVG([...items].reverse(), '20ft', 'top'));
  assert.equal(renderTruckMapSVG(items, '20ft', '3d'), renderTruckMapSVG([...items].reverse(), '20ft', '3d'));
});

test('both views render and carry an accessibility label', () => {
  resetIds();
  const items = [makeItem({ id: 'a', category: 'furniture', estimatedWeightClass: 'heavy', cubicFeet: 60 })];
  for (const view of ['top', '3d'] as const) {
    const svg = renderTruckMapSVG(items, '15ft', view);
    assert.match(svg, /role="img"/);
    assert.match(svg, /aria-label="[^"]+"/);
  }
});
