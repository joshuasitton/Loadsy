import type { InventoryItem, TruckSize } from '../domain/types';
import { stepForItem, type LoadStepOrder } from '../domain/packing';
import { TRUCK_CAPACITY } from '../domain/truck';

/**
 * Client-side truck-map schematic (spec §3 Screen 6).
 *
 * This is intentionally a load-zone diagram, not a bin-packing solution — true 3D
 * optimisation is explicitly out of scope for MVP (§1). It shows WHERE each load
 * step goes and how much of the truck that step's volume occupies, which is what
 * the packing plan actually promises.
 *
 * Deterministic: same items in, same SVG out, so "Save Plan" round-trips.
 */

export type TruckView = 'top' | '3d';

/** Internal truck bed dimensions in feet, by size — used for proportional layout. */
const BED_DIMENSIONS: Record<TruckSize, { lengthFt: number; widthFt: number }> = {
  van: { lengthFt: 9, widthFt: 5.5 },
  '10ft': { lengthFt: 9.9, widthFt: 6.4 },
  '15ft': { lengthFt: 15, widthFt: 7.7 },
  '20ft': { lengthFt: 19.5, widthFt: 7.7 },
  '26ft': { lengthFt: 26, widthFt: 8.1 },
};

const STEP_COLORS: Record<LoadStepOrder, string> = {
  1: '#B4553D',
  2: '#C98A3E',
  3: '#4F7A9B',
  4: '#7A5C9E',
  5: '#4E8A63',
};

const STEP_LABELS: Record<LoadStepOrder, string> = {
  1: 'Heavy',
  2: 'Furniture',
  3: 'Boxes',
  4: 'Fragile',
  5: 'Essentials',
};

const CANVAS = { width: 320, height: 200 };

export function renderTruckMapSVG(
  items: InventoryItem[],
  truckSize: TruckSize,
  view: TruckView = 'top',
): string {
  const zones = computeZones(items);
  const bed = BED_DIMENSIONS[truckSize];
  const body = view === '3d' ? renderIsometric(zones, truckSize) : renderTopDown(zones, bed);

  return [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${CANVAS.width} ${CANVAS.height}" width="100%" height="100%" role="img" aria-label="${ariaLabel(zones, truckSize)}">`,
    body,
    '</svg>',
  ].join('');
}

export interface LoadZone {
  step: LoadStepOrder;
  label: string;
  color: string;
  cubicFeet: number;
  /** share of the loaded volume, 0–1 */
  fraction: number;
}

/** Exported for tests: the zone maths is the part worth asserting on. */
export function computeZones(items: InventoryItem[]): LoadZone[] {
  const totals = new Map<LoadStepOrder, number>();
  for (const item of items) {
    const step = stepForItem(item);
    totals.set(step, (totals.get(step) ?? 0) + item.cubicFeet);
  }

  const loaded = [...totals.values()].reduce((a, b) => a + b, 0);
  if (loaded === 0) return [];

  return ([1, 2, 3, 4, 5] as LoadStepOrder[])
    .filter((step) => (totals.get(step) ?? 0) > 0)
    .map((step) => ({
      step,
      label: STEP_LABELS[step],
      color: STEP_COLORS[step],
      cubicFeet: Math.round((totals.get(step) ?? 0) * 100) / 100,
      fraction: (totals.get(step) ?? 0) / loaded,
    }));
}

function renderTopDown(zones: LoadZone[], bed: { lengthFt: number; widthFt: number }): string {
  const pad = 16;
  const cabWidth = 34;
  const bedX = pad + cabWidth + 6;
  const bedWidth = CANVAS.width - bedX - pad;
  const bedY = 42;
  const aspect = bed.widthFt / bed.lengthFt;
  const bedHeight = Math.min(110, Math.max(60, bedWidth * aspect));

  const parts: string[] = [
    `<rect x="0" y="0" width="${CANVAS.width}" height="${CANVAS.height}" fill="none"/>`,
    `<text x="${pad}" y="24" font-family="system-ui,-apple-system,sans-serif" font-size="11" font-weight="600" fill="#8A94A6">TOP VIEW · LOAD ORDER, BACK TO FRONT</text>`,
    // cab
    `<rect x="${pad}" y="${bedY + bedHeight * 0.15}" width="${cabWidth}" height="${bedHeight * 0.7}" rx="5" fill="#2B3B52"/>`,
    `<text x="${pad + cabWidth / 2}" y="${bedY + bedHeight / 2 + 3}" text-anchor="middle" font-family="system-ui,sans-serif" font-size="8" fill="#8A94A6">CAB</text>`,
  ];

  let cursor = bedX;
  for (const zone of zones) {
    const width = Math.max(6, bedWidth * zone.fraction);
    parts.push(
      `<rect x="${round(cursor)}" y="${bedY}" width="${round(width)}" height="${round(bedHeight)}" fill="${zone.color}" opacity="0.88"/>`,
    );
    if (width > 34) {
      parts.push(
        `<text x="${round(cursor + width / 2)}" y="${round(bedY + bedHeight / 2 - 2)}" text-anchor="middle" font-family="system-ui,sans-serif" font-size="9" font-weight="600" fill="#FFFFFF">${zone.label}</text>`,
        `<text x="${round(cursor + width / 2)}" y="${round(bedY + bedHeight / 2 + 11)}" text-anchor="middle" font-family="system-ui,sans-serif" font-size="8" fill="#FFFFFF" opacity="0.8">${zone.cubicFeet} ft³</text>`,
      );
    }
    cursor += width;
  }

  parts.push(
    `<rect x="${bedX}" y="${bedY}" width="${round(bedWidth)}" height="${round(bedHeight)}" fill="none" stroke="#0F1B2D" stroke-width="1.5" rx="3"/>`,
    `<text x="${bedX}" y="${bedY + bedHeight + 16}" font-family="system-ui,sans-serif" font-size="9" fill="#8A94A6">← loaded first</text>`,
    `<text x="${bedX + bedWidth}" y="${bedY + bedHeight + 16}" text-anchor="end" font-family="system-ui,sans-serif" font-size="9" fill="#8A94A6">loaded last (door) →</text>`,
  );

  return parts.join('');
}

function renderIsometric(zones: LoadZone[], truckSize: TruckSize): string {
  const capacity = TRUCK_CAPACITY[truckSize];
  const originX = 46;
  const originY = 150;
  const totalWidth = 210;
  const wallHeight = 74;
  const depth = 30;

  const parts: string[] = [
    `<text x="16" y="24" font-family="system-ui,-apple-system,sans-serif" font-size="11" font-weight="600" fill="#8A94A6">3D VIEW · ${capacity.min}–${capacity.max} FT³ CAPACITY</text>`,
  ];

  let cursor = originX;
  for (const zone of zones) {
    const width = Math.max(8, totalWidth * zone.fraction);
    const height = wallHeight;
    // front face
    parts.push(
      `<polygon points="${round(cursor)},${originY} ${round(cursor + width)},${originY} ${round(cursor + width)},${round(originY - height)} ${round(cursor)},${round(originY - height)}" fill="${zone.color}" opacity="0.9"/>`,
    );
    // top face
    parts.push(
      `<polygon points="${round(cursor)},${round(originY - height)} ${round(cursor + width)},${round(originY - height)} ${round(cursor + width + depth * 0.6)},${round(originY - height - depth * 0.5)} ${round(cursor + depth * 0.6)},${round(originY - height - depth * 0.5)}" fill="${zone.color}" opacity="0.6"/>`,
    );
    if (width > 30) {
      parts.push(
        `<text x="${round(cursor + width / 2)}" y="${round(originY - height / 2)}" text-anchor="middle" font-family="system-ui,sans-serif" font-size="9" font-weight="600" fill="#FFFFFF">${zone.label}</text>`,
      );
    }
    cursor += width;
  }

  parts.push(
    `<line x1="${originX}" y1="${originY}" x2="${round(cursor)}" y2="${originY}" stroke="#0F1B2D" stroke-width="2"/>`,
    `<text x="${originX}" y="${originY + 18}" font-family="system-ui,sans-serif" font-size="9" fill="#8A94A6">cab end</text>`,
    `<text x="${round(cursor)}" y="${originY + 18}" text-anchor="end" font-family="system-ui,sans-serif" font-size="9" fill="#8A94A6">door end</text>`,
  );

  return parts.join('');
}

function ariaLabel(zones: LoadZone[], truckSize: TruckSize): string {
  if (zones.length === 0) return 'Empty truck diagram — no items in your inventory yet';
  const parts = zones.map((z) => `${z.label} ${Math.round(z.fraction * 100)} percent`);
  return `Load diagram for a ${truckSize} truck, from the cab end to the door: ${parts.join(', ')}`;
}

function round(n: number): number {
  return Math.round(n * 10) / 10;
}
